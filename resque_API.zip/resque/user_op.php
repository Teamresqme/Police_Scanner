<?php
require_once('config.php');

public function register($beacon_id,$name,$mobile,$password,$height,$age,$nationality,$image){
	if(userExist($mobile)){
		$res['st'] = 2;
		$res['msg'] = 'User already exist';
	}else{
		$db = conn();
		$qr = $db->prepare("INSERT INTO `user_info`( `beacon_id`, `name`, `mobile`, `password`, `age`, `height`, `nationality`) VALUES ('$beacon_id','$name','$mobile','$password','$height','$age','$nationality')");
		$qr->execute(); 

		if ($qr->rowCount() > 0) {
			$path = "dp/$username.png";
			file_put_contents($path,base64_decode($image));
			$res['st'] = 1;
			$res['msg'] = 'register success';
		}else{
			
			$res['st'] = 3;
			$res['msg']='register error';
		}
	}
	return $res;
	
}
	
public function login($mobile,$password){
	$db = conn();
	$qr = $db->prepare("SELECT id FROM `resque` WHERE mobile = '$mobile' AND password = '$password' LIMIT 1 ");
	$qr->execute(); 

	if ($qr->rowCount() > 0) {
		$res['id'] = $qr->fetch(PDO::FETCH_ASSOC)['id'];
		$res['st'] = 1;
		$res['msg'] = 'login success';
	}else{
		$res['id'] = array();
		$res['st'] = 3;
		$res['msg']='Oops, Record not found!';
	}
	return $res;

}

public function userExist($mobile){
	$db = conn();
	$qr = $db->prepare("SELECT id FROM `resque` WHERE mobile = '$mobile' LIMIT 1 ");
	$qr->execute(); 

	if ($qr->rowCount() > 0) {
		$res='true';
	}else{
		$res='false';
	}
	return $res;

}

public function trackme($id,$loc,$time){
	$db = conn();
	$qr = $db->prepare("INSERT INTO `user_info`( `last_loc`,`time`,`status`) VALUES ('$loc','$time',1) where `id`='$id' ");
	$qr->execute(); 

	if ($qr->rowCount() > 0) {
			$res['st'] = 1;
			$res['msg'] = 'register success';
		}else{
			$res['st'] = 3;
			$res['msg']='register error';
		}
	return $res;
}


public function updateTrackme($uploaderid,$loc,$time,$beacon_id){
	$id=$this->getMaxBeaconNo($beacon_id);
	$db = conn();
	$qr = $db->prepare("INSERT INTO `current_loc`(`id`, `uploader_id`, `beacon_id`, `location`, `time`) VALUES ('$id','$uploader_id','$beacon_id','$location','$time') ");
	$qr->execute(); 
	
	if ($qr->rowCount() > 0) {
			$res['st'] = 1;
			$res['msg'] = 'update success';
		}else{
			$res['st'] = 3;
			$res['msg']='update error';
		}
	return $res;	
}


 public function getMaxBeaconNo($beacon_id){
		$db = conn();
       $stmt =$db->prepare("SELECT max(`id`)  FROM `current_loc`  where `beacon_id`='$beacon_id'");
        $stmt->execute(); 
        $id = $qr->fetch(PDO::FETCH_ASSOC)['id'];
        return ($id+1);        
}




?>