<?php

if($_SERVER['REQUEST_METHOD']=='POST'){

 

 $status = $_POST['status'];
 
   $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL,"http://abhyas.000webhostapp.com/sendSinglePush.php");
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, "status=".$status);

  $result = curl_exec ($curl);
  curl_close ($curl);
 
 
/* function getToken(){
require_once 'config.php';
        $stmt = $con->prepare("SELECT token FROM devices ");

        $stmt->execute(); 

        $result = $stmt->get_result()->fetch_assoc();

        return array($result['token']);        

    }
	
$token=getToken();
echo $status;
echo $token[0];*/
 
}



?>