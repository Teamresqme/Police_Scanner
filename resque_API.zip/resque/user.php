<?php 
public class v1{
	
	public function register(){
		require_once('user_op.php');
		
		$image=$_POST['image'];
		$beacon_id=$_POST['beacon_id'];
		$name=$_POST['name'];
		$mobile=$_POST['mobile'];
		$password=$_POST['password'];
		$height=$_POST['height'];
		$age=$_POST['age'];
		$nationality=$_POST['nationality'];
		$res=register($beacon_id,$name,$mobile,$password,$height,$age,$nationality,$image);
		
		self::headers();
		echo json_encode($res);
		exit(0);
		
		
	}
	
	
	public function login(){
		require_once('user_op.php');
		$mobile=$_POST['mobile'];
		$password=$_POST['password'];
		$res=login($mobile,$password);

		self::headers();
		echo json_encode($res);
		exit(0);
	}
	
	public function trackme(){
		require_once('user_op.php');
		
		$id=$_POST['id'];
		$loc=$_POST['loc'];
		$time=$_POST['time'];
		$res=trackme($id,$loc,$time);
		
		self::headers();
		echo json_encode($res);
		exit(0);
		
	}
	
	public function updateTrackme(){
		require_once('user_op.php');
		
		$uploaderid=$_POST['id'];
		$loc=$_POST['loc'];
		$time=$_POST['time'];
		$beacon_id=$_POST['beacon_id'];
		$res=updateTrackme($uploaderid,$loc,$time,$beacon_id);
		
		self::headers();
		echo json_encode($res);
		exit(0);
	}
	
	public function updateToken(){
		require_once('police_op.php');
		
		$mobile=$_POST['POST'];
		$token=$_POST['token'];
		$res=updateToken($moilt,$time);
		
		self::headers();
		echo json_encode($res);
		exit(0);
		
	}
	
}





	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$data = $_GET['data'];
		$obj = new v1();
		if (method_exists('v1', $data)) {
			$obj->$data();
		}else{
			$res = array('st' => 0, 'msg'=>'Invalid API call');
			echo json_encode($res);
		}
	}else{
		$res = array('st' => 0, 'msg'=>'Only POST METHOD ALLOWED');
		echo json_encode($res);
	}







?>