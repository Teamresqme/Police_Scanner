<?php 

//importing required files 

//require_once 'config.php';

require_once 'Firebase.php';

require_once 'Push.php'; 

 



 

$response = array(); 

 

if($_SERVER['REQUEST_METHOD']=='POST'){ 

 //hecking the required params 

 if(isset($_POST['status'])){

 

 //creating a new push

 $push = null; 


 $push = new Push(

 $_POST['status']



 

 );

 //}

 

 //getting the push from push object

 $mPushNotification = $push->getPush(); 

 

 //getting the token from database object 
  function getToken(){
require_once 'config.php';
        $stmt = $con->prepare("SELECT token FROM devices ");

        $stmt->execute(); 

        $result = $stmt->get_result()->fetch_assoc();

        return array($result['token']);        

    }
	

 $devicetoken = getToken();

 
//$devicetoken=$token[0];
 //creating firebase class object 

 $firebase = new Firebase(); 

 

 //sending push notification and displaying result 

 echo $firebase->send($devicetoken, $mPushNotification);

 }else{

 $response['error']=true;

 $response['message']='Parameters missing';

 }

}else{

 $response['error']=true;

 $response['message']='Invalid request';

}

 

echo json_encode($response);