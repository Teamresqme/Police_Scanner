<?php 


 class v1{
	
	 function register(){
		require_once('police_op.php');
		
		
		$name=$_POST['name'];
		$mobile=$_POST['mobile'];
		$password=$_POST['password'];
		$res=register($name,$mobile,$password);
		
		self::headers();
		echo json_encode($res);
		exit(0);
		
		
	}
	
	
	public function login(){
		require_once('police_op.php');
		$mobile=$_POST['mobile'];
		$password=$_POST['password'];
		$res=login($mobile,$password);

		self::headers();
		echo json_encode($res);
		exit(0);
	}
	
	 function lostList(){
		require_once('police_op.php');
		$res=lostList_op();

		self::headers();
		echo json_encode($res);
		exit(0);
	}
	
	 function singleDetail(){
		require_once('police_op.php');
		$id=$_POST['id'];
		$res=singleDetail($id);
		
		self::headers();
		echo json_encode($res);
		exit(0);
	}
	
	function updateToken(){
		require_once('police_op.php');
		
		$mobile=$_POST['POST'];
		$token=$_POST['token'];
		$res=updateToken($moilt,$time);
		
		self::headers();
		echo json_encode($res);
		exit(0);
		
	}
	
}





	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$data = $_GET['data'];
		$obj = new v1();
		if (method_exists('v1', $data)) {
			$obj->$data();
		}else{
			$res = array('st' => 0, 'msg'=>'Invalid API call');
			echo json_encode($res);
		}
	}else{
		$res = array('st' => 0, 'msg'=>'Only POST METHOD ALLOWED');
		echo json_encode($res);
	}







?>