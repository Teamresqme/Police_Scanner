<?php 

 

class Push {

    //notification title

    private $status;
	

 

    //notification image url 

   

 

    //initializing values in this constructor

    function __construct($status) {

         $this->status = $status;

         

    }

    

    //getting the push notification

    public function getPush() {

        $res = array();

        $res['data']['status'] = $this->status;

       

        return $res;

    }

 

}