<?php
require_once('config.php');

function register($name,$mobile,$password){
	if(policeExist($mobile)){
		$res['st'] = 2;
		$res['msg'] = 'User already exist';
	}else{
		$db = conn();
		$qr = $db->prepare("INSERT INTO `police_info`( `name`, `mobile`, `password`) VALUES ('$name','$mobile','$password')");
		$qr->execute(); 

		if ($qr->rowCount() > 0) {
			$res['st'] = 1;
			$res['msg'] = 'register success';
		}else{
			
			$res['st'] = 3;
			$res['msg']='register error';
		}
	}
	return $res;
	
}
	
function login($mobile,$password){
	$db = conn();
	$qr = $db->prepare("SELECT id FROM `police_info` WHERE mobile = '$mobile' AND password = '$password' LIMIT 1 ");
	$qr->execute(); 

	if ($qr->rowCount() > 0) {
		$res['id'] = $qr->fetch(PDO::FETCH_ASSOC)['id'];
		$res['st'] = 1;
		$res['msg'] = 'login success';
	}else{
		$res['id'] = array();
		$res['st'] = 3;
		$res['msg']='Oops, Record not found!';
	}
	return $res;

}

function policeExist($mobile){
	$db = conn();
	$qr = $db->prepare("SELECT id FROM `police_info` WHERE mobile = '$mobile' LIMIT 1 ");
	$qr->execute(); 

	if ($qr->rowCount() > 0) {
		$res='true';
	}else{
		$res='false';
	}
	return $res;

}

 function lostList_op(){
	$db = conn();
	$arr = array();
	$qr = $db->prepare("SELECT `id`, `beacon_id`, `name`, `mobile`, `age`, `height`, `nationality`, `aadhar`,  `last_loc`, `time` FROM `user_info` WHERE `status`=1 ");
	$qr->execute();

	if ($qr->rowCount() > 0) {

		while ($r = $qr->fetch(PDO::FETCH_ASSOC)) {
			
			array_push($arr,array("id"=>$r['id'], "beacon_id"=>$r['beacon_id'],"name"=>$r['name'], "mobile"=>$r['mobile'],"age"=>$r['age'], "height"=>$r['height'],"natinality"=>$r['natinality'], "aadhar"=>$r['aadhar'], "last_loc"=>$r['last_loc'], "time"=>$r['time'])));
		}

		$res['lost_list'] = $arr;
		$res['st'] = 1;
		$res['msg'] = 'success';
	}else{
		$res['lost_list'] = array();
		$res['st'] = 3;
		$res['msg']='Oops, Empty!';
	}
	return $res;
}

function singleDetail($id){
	$db = conn();
	$arr = array();
	$qr = $db->prepare("SELECT `id`, `beacon_id`, `name`, `mobile`, `age`, `height`, `nationality`, `aadhar`,  `last_loc`, `time` FROM `user_info` WHERE `id`='$id' ");
	$qr->execute();

	if ($qr->rowCount() > 0) {

		while ($r = $qr->fetch(PDO::FETCH_ASSOC)) {
			
			array_push($arr,array("id"=>$r['id'], "beacon_id"=>$r['beacon_id'],"name"=>$r['name'], "mobile"=>$r['mobile'],"age"=>$r['age'], "height"=>$r['height'],"natinality"=>$r['natinality'], "aadhar"=>$r['aadhar'], "last_loc"=>$r['last_loc'], "time"=>$r['time']));
		}

		$res['lost_list'] = $arr;
		$res['st'] = 1;
		$res['msg'] = 'success';
	}else{
		$res['lost_list'] = array();
		$res['st'] = 3;
		$res['msg']='Oops, Empty!';
	}
	return $res;
}


public function updateToken($mobile,$token){
	if(policeExist($mobile)) {
		$db = conn();
		$qr = $db->prepare("INSERT INTO `police_info`(  `token`) VALUES ('$token') where `mobile`='$mobile'");
		$qr->execute(); 
		if ($qr->rowCount() > 0) {
			$res['st'] = 1;
			$res['msg'] = 'update success';
		}else{
			if ($qr->rowCount() > 0) {
				$res['st'] = 1;
				$res['msg'] = 'register success';
			}else{
				$res['st'] = 3;
				$res['msg']='token error';
			}
			
		}
	}else{
		$res['st'] = 3;
		$res['msg']='token update error';
	}
	return $res;
	
}



?>