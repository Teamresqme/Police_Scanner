<?php



date_default_timezone_set('Asia/Kolkata');
 define('FIREBASE_API_KEY', 'AAAASuzk1Dk:APA91bGssOtajMR2ijz8NS3ila9Ac0ecrUPFUwb9kcho5D9L78hFGbD0QoXMqudMMwEny-gAncmT9w2wTioa8ZDzqUWV49z2niNHDzHsnrTYpIWaxngj5GLChgHXPdKDEMFccAewPznU');

function conn(){
	$dbhost="localhost";
	$dbuser="root";
	$dbpass="";
	$dbname="resque";

	$db = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbuser, $dbpass);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$db->exec("SET NAMES UTF8");
	return $db;
}






?>